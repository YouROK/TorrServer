function Torrents(){
    var R = false, K = SETS("russian"), W = "", Wo = "", B = new TVXBusyService();
        I = function(v){return v ? "msx-white:toggle-on" : "toggle-off"},
        X = function(){
            var ks = [{label: "1", key: "1", offset: K ? "1,0,0,0" : undefined}], l = K ? 1 : 0,
                kl = [
                    ["q","w","e","r","t","y","u","i","o","p","bracket_open","bracket_close"],
                    ["a","s","d","f","g","h","j","k","","l","semicolon","quote"],
                    ["z","","x","c","v","b","n","m","", "'"],
                    ["й","ц","у","к","е","н","г","ш","щ","з","х","ъ"],
                    ["ф","ы","в","а","п","р","о","л","","д","ж","э"],
                    ["я","","ч","с","м","и","т","ь","б","ю","", "ё"]
                ]
            if(K) ks.push({type: "space"});
            for(var i = 2; i < 10; i++) ks.push({label: i = TVXTools.strValue(i), key: i});
            if(K) ks.push({type: "space"});
            ks.push({label: "0", key: "0", offset: K ? "-1,0,0,0" : undefined});
            for(i = 0; i < 3; i++) for(var k = 0; k < 10 + l * 2; k++) ks.push(!kl[i+l*3][k] ? {type: "space"} :
                {label: kl[i+l*3][k], key: kl[i][k], offset: i == 2 && k == 0 ? "1,0,0,0" : i == 1 ? ((k > 8 ? "-" : "") + ".5,0,0,0") : undefined}
            );
            ks[ks.length - 1].key = K ? "accent" : "quote";
            ks[ks.length - 1].offset = "-1,0,0,0";
            ks.push(
                {label: "{ico:backspace}", titleFooter: "{ico:fast-rewind}", key: "delete|red", data: "bs", progress: 1, progressColor: "msx-red", offset: l + ",0,1,0"},
                {type: "space"}
            );
            if(K) ks.push({type: "space"});
            ks.push(
                {label: "{ico:clear}", titleFooter: "{ico:skip-previous}", key: "home", data: "cl", offset: "0,0,1,0"}, {type: "space"},
                {label: "{ico:space-bar}", key: "insert|yellow", data: " ", progress: 1, progressColor: "msx-yellow", offset: "0,0,1,0"}, {type: "space"},
                {label: "{ico:language}", titleFooter: "{ico:fast-forward}", key: "tab|insert", data: "ck", offset: "0,0,1,0", id: "lang"}, {type: "space"}, {type: "space"}
            );
            if(K) ks.push({type: "space"});
            ks.push({label: "{ico:done}", titleFooter: "{ico:skip-next}", key: "end|green", data: "ok", progress: 1, progressColor: "msx-green", offset: (-l-1) + ",0,1,0"});
            return ks;
        },
        Q = function(q){
            var qs = {
                0:    "",
                1:    "Author's}",
                100:  "Amateur one voice",
                101:  "Amateur two voices",
                102:  "Amateur many voices",
                103:  "Amateur studio",
                200:  "Prof. one voice",
                201:  "Prof. two voices",
                202:  "Prof. many voices",
                203:  "Prof. studio",
                300:  "Official",
                301:  "License"
            }
            return (qs = qs[q]) ? ("{ico:msx-white:audiotrack} {dic:a" + q + "|" + qs + "}{br}") : "";
        },
        F = function(d){return d.map(function(t, i){return {
            id: i = TVXTools.strValue(i),
            headline: t.Title,
            image: t.Poster || "",
            text: Q(t.AudioQuality),
            group: "{dic:" + t.Categories + "|" + t.Categories + "}",
            stamp: "{ico:attach-file} " + t.Size + "{tb}{ico:north} " + t.Peer + " {ico:south} " + t.Seed,
            live: !t.Poster && t.IMDBID ? {type: "setup", action: "interaction:commit:message:imdb", data: {imdb: t.IMDBID, id: i}} : null,
            magnet: t.Magnet,
            imdbid: t.IMDBID,
        }})},
        T = function(d){return d.map(function(t){return {
            id: t.hash,
            headline: t.title,
            image: t.poster || "",
            titleFooter: "{ico:attach-file} " + SIZE(t.torrent_size),
            stamp: t.stat < 5 ? ("{ico:north} " + (t.active_peers || 0) + " / " + (t.pending_peers || 0) + " / " + (t.total_peers || 0)) : "",
            stampColor: t.stat > 4 ? "default" : t.stat == 4 ? "msx-red" : t.stat == 3 ? "msx-green" : "msx-yellow",
            group: t.data && t.data.indexOf("GRP:") == 0 ? t.data.substr(4) : null
        }})},
        H = function(i, c, f){return {
            type: "list", reuse: f, cache: f, restore: f, compress: c,
            headline: f ? W : "", extension: "{ico:msx-white:" + (f ? "search" : "bookmarks") + "} " + i.length,
            template: {
                layout: c ? "0,0,8,2" : "0,0,6,2", imageFiller: "height", imageWidth: 1.3, icon: "msx-glass:" + (f ? "search" : "bookmark-border"),
                action: "execute:request:interaction:torrent",
                data: f 
                    ? {action: "add", link: "{context:magnet}", title: "{context:headline}", poster: "{context:image}", group: "{context:group}", imdbid: "{context:imdbid}"} 
                    : {link: "{context:id}"},
                options: f || !i.length ? null : OPTS(
                    {label: "{dic:rem|Remove the torrent}", action: "[cleanup|interaction:commit:message:rem]", data: "{context:id}"}, 
                    null,
                    {label: "{dic:drop|Drop the torrent}", action: "[cleanup|interaction:commit:message:drop]", data: "{context:id}"}
                )
            },
            items: i.length ? i : [{
                headline: "{dic:empty|Nothing found}", action: "back", icon: "arrow-back", 
                offset: c ? "0,0,8,-1" : "0,0,6,-1", centration: "text", iconSize: "small", enumerate: false
            }]
        }},
        M = function(m){return {
            logo: ADDR + "/logo.png",
            ready: typeof m == "string" ? {action: "error:" + m} : null,
            menu: [
                {icon: "bookmarks", label: "{dic:trns|My torrents}", data: "request:interaction:trns@" + window.location.href},
                {icon: "search", label: "{dic:srch|Search torrents}", data: "request:interaction:srch@" + window.location.href, enable: R},
                {type: "separator"},
                {icon: "settings", label: "{dic:label:settings|Settings}", data: {
                    type: "list", extension: "{ico:msx-white:settings}", ready: {action: "interaction:commit:message:set", data: "version"},
                    template: {enumerate: false, type: "control", layout: "0,0,8,1", area: "2,0,8,6", action: "interaction:commit:message:set", data: "{context:id}"},
                    items: [
                        {id: "version", type: "space", image: ADDR + "/logo.png", imageFiller: "height-right", headline: "TorrServer", titleFooter: "https://github.com/YouROK/TorrServer"},
                        {id: "russian", icon: "translate", label: SETS("russian") ? "Switch to english" : "Перевести на русский", extensionIcon: "msx-red:refresh"},
                        {id: "rutor", icon: "search", label: "{dic:srch|Search torrents} (rutor)", extensionIcon: I(R)},
                        {id: "compress", icon: "compress", label: "{dic:compress|Smaller font in lists}", extensionIcon: I(SETS("compress"))},
                        {id: "folders", icon: "folder", label: "{dic:folders|Show folders in torrent}", extensionIcon: I(SETS("folders"))},
                        {icon: "logout", label: "{dic:label:exit|Exit}", action: "exit"}
                    ]
                }}
            ]
        }};
    this.handleData = function(d){
        switch(d.message){
            case "set": 
                switch(d.data){
                    case "version":
                        TVXServices.ajax.get(ADDR + "/echo", {success: function(v){
                            TVXInteractionPlugin.executeAction("update:content:version", {headline: "TorrServer " + v});
                        }}, {dataType: "text"});
                        break;
                    case "russian":
                        SETS(d.data, true);
                        TVXInteractionPlugin.executeAction("reload");
                        break;
                    case "rutor":
                        var e = function(m){TVXInteractionPlugin.error(m); TVXInteractionPlugin.stopLoading()}
                        TVXInteractionPlugin.startLoading();
                        TVXServices.ajax.post(ADDR + "/settings", '{"action":"get"}', {
                            success: function(d){
                                d.EnableRutorSearch = !R;
                                TVXServices.ajax.post(ADDR + "/settings", TVXTools.serialize({action: "set", sets: d}), {
                                    success: function(d){
                                        R = !R; TVXInteractionPlugin.executeAction("reload:menu")
                                        TVXInteractionPlugin.stopLoading();
                                    },
                                    error: e
                                }, {dataType: "text"});
                            },
                            error: e
                        });
                        break;
                    default: TVXInteractionPlugin.executeAction("update:content:" + d.data, {extensionIcon: I(SETS(d.data, true))});
                }
                break;
            case "key": 
                switch(d.data){
                    case "ok":
                        TVXInteractionPlugin.executeAction("[interaction:commit:message:imdb|content:request:interaction:find]");
                        break;
                    case "ck":
                        K = !K;
                        TVXInteractionPlugin.executeAction("reload:content>lang");
                        break;
                    case "cl":
                        W = "";
                    case "bs":
                        W = W ? W.substr(0, W.length - 1) : "";
                        d.data = "";
                    default: TVXInteractionPlugin.executeAction("update:content:underlay:val", {label: (W += d.data) || "{col:msx-white-soft}{dic:input|Enter the word(s) to find}"});
                }
                break;
            case "drop":
            case "rem": 
                TVXServices.ajax.post(ADDR + "/torrents", '{"action":"' + d.message + '","hash":"' + d.data + '"}', {
                    success: function(){TVXInteractionPlugin.executeAction("reload:content")},
                    error: TVXInteractionPlugin.error
                }, {dataType: "text"});
                break;
            case "imdb":
                if(d.data && d.data.imdb) B.onReady(function(){
                    IMDB(function(i){if(i) TVXInteractionPlugin.executeAction("update:content:" + d.data.id, {image: i})}, d.data.imdb)
                });
                else if(W != Wo){
                    Wo = W;
                    B.start();
                    IMDB(function(){B.stop()});
                }
        }
    };
    this.handleRequest = function(i, f){
        var e = function(m){TVXInteractionPlugin.error(m); f();};
        switch(i){
            case "menu":
                TVXServices.ajax.post(ADDR + "/settings", '{"action":"get"}', {
                    success: function(d){f(M(R = d.EnableRutorSearch ? true : false))},
                    error: function(e){f(M(e))}
                });
                return true;
            case "srch":
                f({
                    type: "list", reuse: false, cache: false, restore: false, wrap: true, items: X(), extension: "{ico:msx-white:search} rutor",
                    ready: {action: "interaction:commit:message:key", data: ""},
                    underlay: {items:[
                        {id: "val", type: "space", layout: "0,0,12,1", color: "msx-black-soft", label: ""},
                        {type: "space", color: "msx-glass", layout: "1,1,10,1", offset: "-.05,-.05,.1,.1"},
                        {type: "space", color: "msx-glass", layout: "1,5,10,1", offset: "-.05,-.05,.1,.1"},
                    ]},
                    template: {
                        type: "button", layout: "0,0,1,1", area: K ? "0,1,12,5" : "1,1,10,5", enumerate: false,
                        action: "interaction:commit:message:key", data: "{context:label}"
                    }
                });    
                return true;
            case "find":
                TVXServices.ajax.get(ADDR + "/search/?query=" + TVXTools.strToUrlStr(W), {
                    success: function(d){f(H(F(d), SETS("compress"), true))},
                    error: e
                });
                return true;
            case "trns":
                TVXServices.ajax.post(ADDR + "/torrents", '{"action":"list"}', {
                    success: function(d){f(H(T(d), SETS("compress"), false))},
                    error: e
                });
                return true;
            default: return false;
        }
    }
}
